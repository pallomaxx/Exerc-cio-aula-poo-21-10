import java.util.ArrayList;
import java.util.List;

// Classe abstrata InstrumentoFinanceiro
abstract class InstrumentoFinanceiro {
    protected float saldo;

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public float getSaldo() {
        return saldo;
    }

    // Método abstrato a ser implementado nas subclasses
    public abstract float calcularSaldoTotal();
}

// Subclasse Ação
class Acao extends InstrumentoFinanceiro {
    private int cotas;

    public void setCotas(int cotas) {
        this.cotas = cotas;
    }

    @Override
    public float calcularSaldoTotal() {
        return saldo * cotas;
    }
}

// Subclasse ContaCorrente
class ContaCorrente extends InstrumentoFinanceiro {
    private float limite;

    public void setLimite(float limite) {
        this.limite = limite;
    }

    @Override
    public float calcularSaldoTotal() {
        return saldo + limite;
    }
}

// Subclasse FundoDeAplicacao
class FundoDeAplicacao extends InstrumentoFinanceiro {
    private float rentabilidade;

    public void setRentabilidade(float rentabilidade) {
        this.rentabilidade = rentabilidade;
    }

    @Override
    public float calcularSaldoTotal() {
        return saldo + rentabilidade;
    }
}

// Classe Banco
class Banco {
    private List<InstrumentoFinanceiro> instrumentos = new ArrayList<>();

    public void adicionar(InstrumentoFinanceiro instrumento) {
        instrumentos.add(instrumento);
    }

    public float calcularSaldos() {
        float total = 0;
        for (InstrumentoFinanceiro instrumento : instrumentos) {
            total += instrumento.calcularSaldoTotal();
        }
        return total;
    }

    public static void main(String[] args) {
        Banco banco = new Banco();

        // Criando e adicionando instrumentos financeiros
        Acao acao = new Acao();
        acao.setSaldo(100);
        acao.setCotas(5);
        banco.adicionar(acao);

        ContaCorrente conta = new ContaCorrente();
        conta.setSaldo(200);
        conta.setLimite(100);
        banco.adicionar(conta);

        FundoDeAplicacao fundo = new FundoDeAplicacao();
        fundo.setSaldo(300);
        fundo.setRentabilidade(50);
        banco.adicionar(fundo);

        // Calculando o saldo total de todos os instrumentos
        System.out.println("Saldo total: " + banco.calcularSaldos());
    }
}
